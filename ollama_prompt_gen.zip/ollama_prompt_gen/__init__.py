from krita import DockWidgetFactory, DockWidgetFactoryBase, Krita
from .ollama_plugin import OllamaPromptDocker

instance = Krita.instance()
dock_widget_factory = DockWidgetFactory("ollama_prompt_docker", DockWidgetFactoryBase.DockRight, OllamaPromptDocker)
instance.addDockWidgetFactory(dock_widget_factory)
