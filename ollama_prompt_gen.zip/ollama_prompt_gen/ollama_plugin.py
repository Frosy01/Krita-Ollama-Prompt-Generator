from krita import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
import json
import urllib.request
import subprocess
import os

class OllamaPromptDocker(DockWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ollama Prompt")
        self.mainWidget = QWidget(self)
        self.setWidget(self.mainWidget)
        self.layout = QVBoxLayout(self.mainWidget)
        
        self.chat_context = None # Store conversation history

        # Settings
        self.settingsLayout = QHBoxLayout()
        self.modelLabel = QLabel("Model:")
        self.modelCombo = QComboBox()
        self.modelCombo.setMinimumWidth(150)
        
        self.refreshModelsBtn = QPushButton("Of") # Small refresh icon/text
        self.refreshModelsBtn.setFixedWidth(30)
        self.refreshModelsBtn.setToolTip("Refresh Model List")
        self.refreshModelsBtn.clicked.connect(self.refresh_models)
        
        self.settingsLayout.addWidget(self.modelLabel)
        self.settingsLayout.addWidget(self.modelCombo)
        self.settingsLayout.addWidget(self.refreshModelsBtn)
        
        self.resetBtn = QPushButton("🔄 Reset Context")
        self.resetBtn.clicked.connect(self.reset_context)
        self.settingsLayout.addWidget(self.resetBtn)
        
        self.layout.addLayout(self.settingsLayout)

        # Initial fetch (Moved to end)

        # Input
        self.inputLabel = QLabel("Input Prompt:")
        self.layout.addWidget(self.inputLabel)
        self.inputText = QTextEdit()
        self.inputText.setMaximumHeight(100)
        self.layout.addWidget(self.inputText)

        # Voice Button
        self.voiceBtn = QPushButton("🎤 Record Voice")
        self.voiceBtn.clicked.connect(self.start_recording)
        self.layout.addWidget(self.voiceBtn)

        # Generate Button
        self.generateBtn = QPushButton("✨ Auto Generate / Refine")
        self.generateBtn.clicked.connect(self.generate_prompt)
        self.layout.addWidget(self.generateBtn)

        # Output
        self.outputLabel = QLabel("Generated Prompt:")
        self.layout.addWidget(self.outputLabel)
        self.outputText = QTextEdit()
        # Actions - Button Layout
        self.actionLayout = QHBoxLayout()
        
        # English Button
        self.copyEngBtn = QPushButton("📋 Copy English")
        self.copyEngBtn.setToolTip("Copy only the English prompt")
        self.copyEngBtn.clicked.connect(self.copy_english_prompt)
        self.actionLayout.addWidget(self.copyEngBtn)

        # Chinese Button
        self.copyChnBtn = QPushButton("📋 Copy Chinese")
        self.copyChnBtn.setToolTip("Copy only the Chinese translation")
        self.copyChnBtn.clicked.connect(self.copy_chinese_prompt)
        self.actionLayout.addWidget(self.copyChnBtn)
        
        self.layout.addLayout(self.actionLayout)

        self.current_send_mode = "english" # Default to English
        self.sendBtn = QPushButton("🚀 Send English to AI Plugin")
        self.sendBtn.setToolTip("Paste English prompt to AI Diffusion plugin")
        self.sendBtn.clicked.connect(self.send_to_diffusion)
        self.layout.addWidget(self.sendBtn)
        
        self.statusLabel = QLabel("Ready")
        self.layout.addWidget(self.statusLabel)
        
        # Initial fetch (Safe to call now)
        self.refresh_models()

    def start_recording(self):
        self.statusLabel.setText("Recording... (Please speak)")
        QApplication.processEvents()
        
        script_path = os.path.join(os.path.dirname(__file__), "voice_recorder.py")
        
        try:
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            
            process = subprocess.Popen(
                ["python", script_path], 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                text=True,
                startupinfo=startupinfo
            )
            stdout, stderr = process.communicate()
            
            if process.returncode == 0:
                text = stdout.strip()
                if text:
                    current = self.inputText.toPlainText()
                    if current:
                        self.inputText.setPlainText(current + " " + text)
                    else:
                        self.inputText.setPlainText(text)
                    self.statusLabel.setText("Voice recognized.")
                else:
                    self.statusLabel.setText("No speech detected.")
            else:
                self.statusLabel.setText(f"Error. Check console.")
                print(f"Recorder Error: {stderr}")
        except Exception as e:
            self.statusLabel.setText(f"Failed: {str(e)}")

    def reset_context(self):
        self.chat_context = None
        self.statusLabel.setText("Context cleared. Started new conversation.")

    def refresh_models(self):
        self.modelCombo.clear()
        try:
            url = "http://localhost:11434/api/tags"
            with urllib.request.urlopen(url, timeout=2) as response:
                data = json.loads(response.read().decode('utf-8'))
                # Extract model names
                models = [m['name'] for m in data.get('models', [])]
                models.sort()
                
                if models:
                    self.modelCombo.addItems(models)
                    # Try to set a good default
                    defaults = ["gemma3:27b", "gemma2", "llama3", "mistral"]
                    for d in defaults:
                        for m in models:
                            if d in m:
                                self.modelCombo.setCurrentText(m)
                                break
                        else:
                            continue
                        break
                    self.statusLabel.setText(f"Found {len(models)} models.")
                else:
                    self.modelCombo.addItem("gemma3:27b") # Fallback
                    self.statusLabel.setText("No models found in Ollama.")
                    
        except Exception as e:
            self.modelCombo.addItem("gemma3:27b") # Fallback
            self.statusLabel.setText("Ollama not running?")
            print(f"Model Fetch Error: {e}")


    def generate_prompt(self):
        prompt = self.inputText.toPlainText()
        if not prompt:
            self.statusLabel.setText("Please enter a prompt first.")
            return

        if not prompt:
            self.statusLabel.setText("Please enter a prompt first.")
            return

        model = self.modelCombo.currentText()
        self.statusLabel.setText("Generating...")
        QApplication.processEvents()

        try:
            url = "http://localhost:11434/api/generate"
            system_instruction = (
                "Act as a professional Concept Artist and Prompt Engineer. "
                "Analyze the user's input. If the input suggests blending concepts (e.g., 'Ferrari mixed with Toyota'), "
                "do not just list them. Instead, invent a NEW, unique design that creatively fuses the distinct visual traits, "
                "styles, and philosophy of the inputs. Describe the resulting subject in natural language with high detail, "
                "focusing on shape, aesthetic, material, lighting, and composition.\n"
                "Output exactly in this format:\n\n"
                "---ENGLISH START---\n"
                "[Detailed English prompt describing the fused concept]\n"
                "---ENGLISH END---\n\n"
                "---CHINESE START---\n"
                "[Traditional Chinese translation]\n"
                "---CHINESE END---"
            )

            data = {
                "model": model,
                "prompt": f"{system_instruction}\n\nUser Input: {prompt}",
                "stream": False
            }
            
            if self.chat_context:
                data["context"] = self.chat_context
            
            req = urllib.request.Request(url, data=json.dumps(data).encode('utf-8'), headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                generated = result.get("response", "")
                self.chat_context = result.get("context", []) # Update context
                self.outputText.setPlainText(generated)
                self.statusLabel.setText("Done.")
        except Exception as e:
            self.statusLabel.setText(f"Ollama Error: {str(e)}")

    def extract_english_prompt(self, full_text):
        """Helper to extract just the English prompt."""
        import re
        
        # 1. Try explicit tags (Best Case)
        match = re.search(r"---ENGLISH START---(.*?)---ENGLISH END---", full_text, re.DOTALL)
        if match: return match.group(1).strip()
        
        # 2. Try Markdown/Header patterns
        # Look for English header ... until Chinese header
        pattern = r"(?:\*\*English Prompt\*\*|English Prompt|English|1\.)[:\s]*(.*?)(?=\n.*?(?:\*\*Chinese|Chinese|Translation|2\.|$))"
        match = re.search(pattern, full_text, re.DOTALL | re.IGNORECASE)
        if match: 
            candidate = match.group(1).strip()
            # Double check: if candidate is too short, maybe regex failed?
            if len(candidate) > 5:
                # Cleanup trailing "1." or "2." if caught
                return re.sub(r"\n\s*\d+\.\s*$", "", candidate).strip()

        # 3. Fallback: Aggressive Keyword Split
        # If we didn't match a nice block, let's just cut off at "Chinese" or "翻譯"
        # This prevents sending the chinese part to the AI plugin
        lower_text = full_text.lower()
        
        # List of cutoff words
        cutoffs = ["**chinese", "chinese translation", "chinese:", "翻譯:", "\n2. ", "---chinese"]
        
        idx = -1
        for cutoff in cutoffs:
            found = lower_text.find(cutoff)
            if found != -1:
                # Keep the earliest cutoff
                if idx == -1 or found < idx:
                    idx = found
        
        if idx != -1:
            return full_text[:idx].strip()

        # 4. Last Resort: If the text seems to be mostly ASCII, return it.
        # If it has a lot of non-ASCII (Chinese), maybe warn?
        # For now, return full text but trim
        return full_text.strip()

    def extract_chinese_prompt(self, full_text):
        """Helper to extract just the Chinese translation."""
        import re
        
        # 1. Try explicit tags (Best Case)
        match = re.search(r"---CHINESE START---(.*?)---CHINESE END---", full_text, re.DOTALL)
        if match: return match.group(1).strip()

        # 2. Try Robust Regex for common headers
        # Case insensitive, handles "**Chinese Translation**", "Chinese:", "翻譯:", "2. "
        # We assume the Chinese part goes until the end of the text
        pattern = r"(?:[\*\#\-]*\s*(?:Chinese(?: Translation)?|Translation|翻譯|Trad\.? Chinese)\s*[\*\#\-]*|\n\s*2\.)\s*[:\.]?\s*(.*)"
        match = re.search(pattern, full_text, re.DOTALL | re.IGNORECASE)
        if match: 
            return match.group(1).strip()
        
        # 3. Fallback: Search for keywords from the BOTTOM up (rfind)
        # This prevents matching "Chinese" inside the English prompt (e.g. "A Chinese style building")
        lower_text = full_text.lower()
        keywords = ["chinese translation", "chinese:", "翻譯:", "**chinese", "chinese"]
        
        for kw in keywords:
            idx = lower_text.rfind(kw)
            if idx != -1:
                # Safety check: if the keyword is very close to the start, it might not be a header
                # But usually Chinese is the second part.
                
                # Check if it's followed by "style" or "fashion", if so ignore (simple heuristic)
                snippet = lower_text[idx:idx+20]
                if "style" in snippet or "fashion" in snippet:
                    continue
                    
                return full_text[idx + len(kw):].strip(" :*-\n")
        
        return "無法抓取中文翻譯 (Could not extract)"

    def copy_english_prompt(self):
        full_text = self.outputText.toPlainText()
        text = self.extract_english_prompt(full_text)
        QApplication.clipboard().setText(text)
        self.statusLabel.setText("Copied English prompt!")
        
        # Update Send Button Mode
        self.current_send_mode = "english"
        self.sendBtn.setText("🚀 Send English to AI Plugin")

    def copy_chinese_prompt(self):
        full_text = self.outputText.toPlainText()
        text = self.extract_chinese_prompt(full_text)
        if text:
            QApplication.clipboard().setText(text)
            self.statusLabel.setText("Copied Chinese translation!")
            
            # Update Send Button Mode
            self.current_send_mode = "chinese"
            self.sendBtn.setText("🚀 Send Chinese to AI Plugin")
        else:
            self.statusLabel.setText("No Chinese translation found.")

    def send_to_diffusion(self):
        """Attempts to find the AI Diffusion plugin and set the text."""
        full_text = self.outputText.toPlainText()
        
        if self.current_send_mode == "chinese":
            text_to_send = self.extract_chinese_prompt(full_text)
            label = "Chinese"
        else:
            text_to_send = self.extract_english_prompt(full_text)
            label = "English"
        
        if not text_to_send or "Could not extract" in text_to_send:
            self.statusLabel.setText(f"No {label} text to send.")
            return

        # Copy to clipboard anyway as backup
        clipboard = QApplication.clipboard()
        clipboard.setText(text_to_send)

        # Traverse widgets to find the target
        app = QApplication.instance()
        target_found = False
        
        # We look for a DockWidget that might be the AI plugin
        # Common names: "AI Image Generation", "Stable Diffusion", "AI Diffusion"
        # The user's screenshot had "AI" in the title (AI 影像生成)
        
        potential_dockers = []
        for widget in app.topLevelWidgets():
            if isinstance(widget, QMainWindow):
                potential_dockers.extend(widget.findChildren(QDockWidget))
        
        target_input = None
        
        for docker in potential_dockers:
            title = docker.windowTitle()
            # Check for keywords in title (both English and Chinese common terms)
            if any(k in title for k in ["AI", "Diffusion", "Generation", "影像", "生成"]):
                # Look for QTextEdit or QPlainTextEdit inside
                text_edits = docker.findChildren(QTextEdit) + docker.findChildren(QPlainTextEdit)
                
                # Filter out read-only log windows if possible, or pick the largest one
                valid_inputs = [t for t in text_edits if not t.isReadOnly() and t.isVisible()]
                
                if valid_inputs:
                    # Heuristic: The prompt box is usually the first visible input or the one near the top
                    target_input = valid_inputs[0]
                    target_found = True
                    break
        
        if target_found and target_input:
            # Check if it already has text, maybe append or replace? 
            # Usually replace is better for a "Generator"
            current_text = target_input.toPlainText()
            
            target_input.setPlainText(text_to_send)
            self.statusLabel.setText(f"Sent {label} to '{docker.windowTitle()}'!")
        else:
            self.statusLabel.setText("Target plugin not found. Copied to Clipboard instead.")
            print("Could not find a standard QTextEdit in any dock widget matching 'AI/Diffusion'")

    def canvasChanged(self, canvas):
        pass
