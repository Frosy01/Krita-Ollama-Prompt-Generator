import speech_recognition as sr
import sys

# Ensure encoding is utf-8 for stdout
sys.stdout.reconfigure(encoding='utf-8')

def record_audio():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        # Adjust for ambient noise
        r.adjust_for_ambient_noise(source, duration=0.5)
        # Listen
        try:
            audio = r.listen(source, timeout=5, phrase_time_limit=10)
        except sr.WaitTimeoutError:
            return

    try:
        # Recognize speech using Google Speech Recognition
        # We use zh-TW as default, but it can be changed.
        # Ideally, we might want to detect or let user choose, but for now zh-TW is good for the user.
        text = r.recognize_google(audio, language="zh-TW")
        print(text)
    except sr.UnknownValueError:
        pass
    except sr.RequestError as e:
        sys.stderr.write(f"API unavailable: {e}\n")

if __name__ == "__main__":
    try:
        record_audio()
    except Exception as e:
        sys.stderr.write(f"Error: {e}\n")
        sys.exit(1)
